const SPREADSHEET_ID = '';

const SHEET_NAMES = {
  inbox: 'Lead_Inbox',
  pipeline: 'Follow_Up_Pipeline',
  chatbot: 'Chatbot_Capture_Log',
  log: 'Automation_Log',
  settings: 'Settings',
  dashboard: 'Dashboard'
};

const LEAD_HEADERS = [
  'Lead_ID','Captured_At','Full_Name','Contact_Number_REQUIRED','Contact_Link','Email','Business_Name','Service_Interest','Main_Problem','Timeline','Source','Status','Priority','Follow_Up_Date','Next_Action','Owner','Notes','Raw_Message','User_Agent','Request_ID'
];

const PIPELINE_HEADERS = [
  'Lead_ID','Captured_At','Full_Name','Contact_Number','Contact_Link','Service_Interest','Status','Priority','Follow_Up_Date','Next_Action','Last_Action','Notes'
];

const CHATBOT_HEADERS = [
  'Logged_At','Lead_ID','Full_Name','Contact_Number','Email','Service_Interest','Business_Name','Timeline','Raw_Message','User_Agent','Request_ID'
];

const LOG_HEADERS = [
  'Logged_At','Event','Status','Lead_ID','Message','Payload_Snapshot'
];

const STATUS_LIST = ['New','Contacted','Need Follow-Up','Proposal Sent','Won','Lost','Archived','Invalid'];
const PRIORITY_LIST = ['Hot','Warm','Cold','Needs Discovery'];
const SERVICE_LIST = ['Lead Capture Automation','Instant Response System','CRM / Google Sheets Tracker','AI Chatbot','Website / Landing Page','Document Extraction','Not sure yet'];
const TIMELINE_LIST = ['ASAP','This week','This month','Just exploring'];
const SOURCE_LIST = ['chatbot-widget','contact-form','github-funnel','linkedin-proof','facebook-proof','manual-entry'];
const OWNER_LIST = ['Alecs','AM777','Unassigned'];

function getBook_() {
  if (SPREADSHEET_ID && SPREADSHEET_ID.trim()) return SpreadsheetApp.openById(SPREADSHEET_ID.trim());
  return SpreadsheetApp.getActiveSpreadsheet();
}

function doGet() {
  return json_({ status: 'ok', message: 'AM777 Lead Webhook is live', required: 'Full_Name + Contact_Number' });
}

function doPost(e) {
  const ss = getBook_();
  setupAM777LeadCRM();

  try {
    const payload = parsePayload_(e);

    if (payload.website && String(payload.website).trim() !== '') {
      appendLog_('Rejected Bot', 'Rejected', '', 'Honeypot field was filled.', payload);
      return json_({ status: 'rejected', message: 'Bot rejected' });
    }

    const lead = normalizeLead_(payload);
    const validation = validateLead_(lead);

    if (!validation.ok) {
      appendLog_('Rejected Lead', 'Missing Required Field', '', validation.message, payload);
      return json_({ status: 'error', message: validation.message });
    }

    const now = new Date();
    const leadId = makeLeadId_();
    const priority = scoreLead_(lead);
    const followUpDate = getFollowUpDate_(priority);
    const contactLink = makeWhatsAppLink_(lead.contactNumber);
    const nextAction = getNextAction_(lead, priority);
    const requestId = lead.requestId || Utilities.getUuid();

    const inboxRow = [
      leadId,
      now,
      lead.fullName,
      lead.contactNumber,
      contactLink,
      lead.email,
      lead.businessName,
      lead.serviceInterest,
      lead.mainProblem,
      lead.timeline,
      lead.source,
      'New',
      priority,
      followUpDate,
      nextAction,
      'Alecs',
      '',
      lead.rawMessage,
      lead.userAgent,
      requestId
    ];

    const pipelineRow = [
      leadId,
      now,
      lead.fullName,
      lead.contactNumber,
      contactLink,
      lead.serviceInterest,
      'New',
      priority,
      followUpDate,
      nextAction,
      '',
      ''
    ];

    const chatbotRow = [
      now,
      leadId,
      lead.fullName,
      lead.contactNumber,
      lead.email,
      lead.serviceInterest,
      lead.businessName,
      lead.timeline,
      lead.rawMessage,
      lead.userAgent,
      requestId
    ];

    ss.getSheetByName(SHEET_NAMES.inbox).appendRow(inboxRow);
    ss.getSheetByName(SHEET_NAMES.pipeline).appendRow(pipelineRow);
    ss.getSheetByName(SHEET_NAMES.chatbot).appendRow(chatbotRow);

    appendLog_('Lead Captured', 'Success', leadId, `${lead.fullName} | ${lead.contactNumber} | ${lead.serviceInterest}`, payload);

    return json_({ status: 'success', message: 'Lead saved', lead_id: leadId, priority: priority });

  } catch (err) {
    appendLog_('Script Error', 'Failed', '', String(err), e ? { parameter: e.parameter || {}, postData: e.postData ? e.postData.contents : '' } : {});
    return json_({ status: 'error', message: String(err) });
  }
}

function setupAM777LeadCRM() {
  const ss = getBook_();

  ensureSheet_(ss, SHEET_NAMES.inbox, LEAD_HEADERS);
  ensureSheet_(ss, SHEET_NAMES.pipeline, PIPELINE_HEADERS);
  ensureSheet_(ss, SHEET_NAMES.chatbot, CHATBOT_HEADERS);
  ensureSheet_(ss, SHEET_NAMES.log, LOG_HEADERS);
  ensureSettings_(ss);
  ensureDashboard_(ss);
  applyFormats_(ss);

  return json_({ status: 'ok', message: 'AM777 Lead CRM setup complete' });
}

function ensureSheet_(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);

  const firstRow = sh.getRange(1, 1, 1, headers.length).getValues()[0];
  const hasHeaders = firstRow.join('').trim() !== '';

  if (!hasHeaders) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  } else {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  }

  sh.setFrozenRows(1);
  return sh;
}

function ensureSettings_(ss) {
  let sh = ss.getSheetByName(SHEET_NAMES.settings);
  if (!sh) sh = ss.insertSheet(SHEET_NAMES.settings);
  sh.clear();

  const headers = ['Status','Priority','Service_Interest','Timeline','Source','Owner'];
  const maxRows = Math.max(STATUS_LIST.length, PRIORITY_LIST.length, SERVICE_LIST.length, TIMELINE_LIST.length, SOURCE_LIST.length, OWNER_LIST.length);
  const rows = [];

  for (let i = 0; i < maxRows; i++) {
    rows.push([
      STATUS_LIST[i] || '',
      PRIORITY_LIST[i] || '',
      SERVICE_LIST[i] || '',
      TIMELINE_LIST[i] || '',
      SOURCE_LIST[i] || '',
      OWNER_LIST[i] || ''
    ]);
  }

  sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  sh.getRange(2, 1, rows.length, headers.length).setValues(rows);
  sh.setFrozenRows(1);
}

function ensureDashboard_(ss) {
  let sh = ss.getSheetByName(SHEET_NAMES.dashboard);
  if (!sh) sh = ss.insertSheet(SHEET_NAMES.dashboard);
  sh.clear();

  sh.getRange('A1').setValue('AM777 Lead Capture Dashboard');
  sh.getRange('A2').setValue('Fresh lead tracking for GitHub funnel + Yamabot. Contact number is mandatory.');
  sh.getRange('A4:B9').setValues([
    ['Metric','Value'],
    ['Total Leads','=COUNTA(Lead_Inbox!A2:A)'],
    ['New Leads','=COUNTIF(Lead_Inbox!L2:L,"New")'],
    ['Hot Leads','=COUNTIF(Lead_Inbox!M2:M,"Hot")'],
    ['Needs Follow-Up','=COUNTIF(Lead_Inbox!L2:L,"Need Follow-Up")'],
    ['Missing Contact #','=COUNTBLANK(FILTER(Lead_Inbox!D2:D,Lead_Inbox!A2:A<>""))']
  ]);
  sh.getRange('D4:K4').setValues([['Lead_ID','Full_Name','Contact_Number','Service','Priority','Status','Follow_Up_Date','Next_Action']]);
  sh.getRange('D5').setFormula('=IFERROR(FILTER({Lead_Inbox!A2:A,Lead_Inbox!C2:C,Lead_Inbox!D2:D,Lead_Inbox!H2:H,Lead_Inbox!M2:M,Lead_Inbox!L2:L,Lead_Inbox!N2:N,Lead_Inbox!O2:O},Lead_Inbox!A2:A<>""),"No active leads yet")');
  sh.setFrozenRows(3);
}

function applyFormats_(ss) {
  const green = '#BBF7D0';
  const light = '#F0FDF4';
  const blue = '#DBEAFE';
  const yellow = '#FEF3C7';

  const inbox = ss.getSheetByName(SHEET_NAMES.inbox);
  const pipeline = ss.getSheetByName(SHEET_NAMES.pipeline);
  const chatbot = ss.getSheetByName(SHEET_NAMES.chatbot);
  const log = ss.getSheetByName(SHEET_NAMES.log);
  const dash = ss.getSheetByName(SHEET_NAMES.dashboard);
  const settings = ss.getSheetByName(SHEET_NAMES.settings);

  [inbox, pipeline, chatbot, log, dash, settings].forEach(sh => {
    if (!sh) return;
    sh.getDataRange().setFontFamily('Arial').setFontSize(10);
  });

  styleHeader_(inbox, green, '#064E3B');
  styleHeader_(pipeline, green, '#064E3B');
  styleHeader_(chatbot, blue, '#1E3A8A');
  styleHeader_(log, yellow, '#92400E');
  styleHeader_(settings, light, '#064E3B');

  inbox.setFrozenColumns(4);
  pipeline.setFrozenColumns(3);

  inbox.setColumnWidths(1, 20, 145);
  inbox.setColumnWidth(3, 190);
  inbox.setColumnWidth(4, 190);
  inbox.setColumnWidth(5, 120);
  inbox.setColumnWidth(8, 220);
  inbox.setColumnWidth(9, 320);
  inbox.setColumnWidth(15, 260);
  inbox.setColumnWidth(18, 360);

  pipeline.setColumnWidths(1, 12, 150);
  pipeline.setColumnWidth(3, 190);
  pipeline.setColumnWidth(4, 190);
  pipeline.setColumnWidth(6, 220);
  pipeline.setColumnWidth(10, 260);
  pipeline.setColumnWidth(12, 320);

  chatbot.setColumnWidths(1, 11, 160);
  chatbot.setColumnWidth(9, 380);
  log.setColumnWidths(1, 6, 170);
  log.setColumnWidth(5, 360);
  log.setColumnWidth(6, 420);

  applyDropdown_(inbox, 8, SERVICE_LIST);
  applyDropdown_(inbox, 10, TIMELINE_LIST);
  applyDropdown_(inbox, 11, SOURCE_LIST);
  applyDropdown_(inbox, 12, STATUS_LIST);
  applyDropdown_(inbox, 13, PRIORITY_LIST);
  applyDropdown_(inbox, 16, OWNER_LIST);
  applyDropdown_(pipeline, 6, SERVICE_LIST);
  applyDropdown_(pipeline, 7, STATUS_LIST);
  applyDropdown_(pipeline, 8, PRIORITY_LIST);

  const phoneRule = SpreadsheetApp.newDataValidation()
    .requireTextLengthGreaterThanOrEqualTo(8)
    .setAllowInvalid(false)
    .setHelpText('Contact number is required for follow-up.')
    .build();

  inbox.getRange(2, 4, 999, 1).setDataValidation(phoneRule);
  pipeline.getRange(2, 4, 999, 1).setDataValidation(phoneRule);

  if (dash) {
    dash.getRange('A1:K1').merge().setFontWeight('bold').setFontSize(18).setFontColor('#111827');
    dash.getRange('A2:K2').merge().setFontColor('#6B7280');
    dash.getRange('A4:B4').setBackground(green).setFontWeight('bold');
    dash.getRange('D4:K4').setBackground(green).setFontWeight('bold').setFontColor('#064E3B');
    dash.setColumnWidths(1, 11, 150);
  }
}

function styleHeader_(sh, bg, color) {
  if (!sh) return;
  const lastCol = sh.getLastColumn();
  sh.getRange(1, 1, 1, lastCol).setBackground(bg).setFontWeight('bold').setFontColor(color).setWrap(true);
  sh.getDataRange().setVerticalAlignment('middle');
}

function applyDropdown_(sh, col, values) {
  if (!sh) return;
  const rule = SpreadsheetApp.newDataValidation().requireValueInList(values, true).setAllowInvalid(true).build();
  sh.getRange(2, col, 999, 1).setDataValidation(rule);
}

function parsePayload_(e) {
  const out = {};

  if (e && e.parameter) {
    Object.keys(e.parameter).forEach(k => out[k] = e.parameter[k]);
  }

  if (e && e.postData && e.postData.contents) {
    const raw = e.postData.contents;
    const type = String(e.postData.type || '').toLowerCase();

    if (type.indexOf('application/json') !== -1 || raw.trim().charAt(0) === '{') {
      try {
        const obj = JSON.parse(raw);
        Object.keys(obj).forEach(k => out[k] = obj[k]);
      } catch (err) {}
    } else {
      raw.split('&').forEach(part => {
        const pair = part.split('=');
        if (!pair[0]) return;
        const key = decodeURIComponent(pair[0].replace(/\+/g, ' '));
        const val = decodeURIComponent((pair.slice(1).join('=') || '').replace(/\+/g, ' '));
        out[key] = val;
      });
    }
  }

  return out;
}

function normalizeLead_(p) {
  const fullName = pick_(p, ['full_name','name','Full_Name','Name']);
  const contactNumber = normalizePhone_(pick_(p, ['contact_number','contactNumber','phone','mobile','whatsapp','Contact_Number','Contact_Number_REQUIRED']));
  const email = pick_(p, ['email','Email']);
  const businessName = pick_(p, ['business_name','business','businessName','Business_Name','businessType']);
  const serviceInterest = pick_(p, ['service_interest','serviceInterested','service','systemType','Service_Interest']) || 'Not sure yet';
  const timeline = pick_(p, ['timeline','Timeline']) || 'Just exploring';
  const mainProblem = pick_(p, ['main_problem','problem','message','Main_Problem']) || '';
  const rawMessage = pick_(p, ['message','main_problem','problem','raw_message']) || '';
  const source = pick_(p, ['source','page','Source']) || 'github-funnel';
  const userAgent = pick_(p, ['userAgent','user_agent','User_Agent']) || '';
  const requestId = pick_(p, ['request_id','requestId','Request_ID']) || '';

  return {
    fullName,
    contactNumber,
    email,
    businessName,
    serviceInterest,
    timeline,
    mainProblem,
    rawMessage,
    source,
    userAgent,
    requestId
  };
}

function validateLead_(lead) {
  if (!lead.fullName) return { ok: false, message: 'Full name is required.' };
  if (!lead.contactNumber) return { ok: false, message: 'Contact number is required.' };
  const digits = lead.contactNumber.replace(/\D/g, '');
  if (digits.length < 8 || digits.length > 15) return { ok: false, message: 'Valid mobile/WhatsApp contact number is required.' };
  return { ok: true, message: 'Valid' };
}

function pick_(obj, keys) {
  for (let i = 0; i < keys.length; i++) {
    const v = obj[keys[i]];
    if (v !== undefined && v !== null && String(v).trim() !== '') return String(v).trim();
  }
  return '';
}

function normalizePhone_(value) {
  if (!value) return '';
  let v = String(value).trim();
  v = v.replace(/[^\d+]/g, '');
  if (v.indexOf('+') > 0) v = v.replace(/\+/g, '');
  return v;
}

function scoreLead_(lead) {
  const urgent = /asap|this week/i.test(lead.timeline || '');
  const clearNeed = lead.serviceInterest && !/not sure/i.test(lead.serviceInterest);
  if (urgent && clearNeed) return 'Hot';
  if (clearNeed) return 'Warm';
  return 'Needs Discovery';
}

function getFollowUpDate_(priority) {
  const d = new Date();
  if (priority === 'Hot') return d;
  d.setDate(d.getDate() + 1);
  return d;
}

function getNextAction_(lead, priority) {
  if (priority === 'Hot') return 'Message/call today and confirm requirements.';
  if (priority === 'Warm') return 'Send short discovery message and ask for details.';
  return 'Ask 2-3 questions to clarify the best-fit automation.';
}

function makeLeadId_() {
  return 'AM777-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMdd-HHmmss') + '-' + Math.floor(Math.random() * 900 + 100);
}

function makeWhatsAppLink_(phone) {
  const clean = String(phone || '').replace(/\D/g, '');
  if (!clean) return '';
  return 'https://wa.me/' + clean;
}

function appendLog_(event, status, leadId, message, payload) {
  const ss = getBook_();
  let sh = ss.getSheetByName(SHEET_NAMES.log);
  if (!sh) sh = ensureSheet_(ss, SHEET_NAMES.log, LOG_HEADERS);

  let snapshot = '';
  try {
    snapshot = JSON.stringify(payload || {});
    if (snapshot.length > 45000) snapshot = snapshot.substring(0, 45000);
  } catch (err) {
    snapshot = String(payload || '');
  }

  sh.appendRow([new Date(), event, status, leadId || '', message || '', snapshot]);
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

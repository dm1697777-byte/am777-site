AM777 Strict Contact Lead Capture Sync Package

Files:
1. index.html
   - GitHub Pages-ready funnel page.
   - Chatbot now requires Contact Number.
   - Contact form now requires Contact Number.
   - Replace APPS_SCRIPT_URL with your deployed Apps Script Web App URL.

2. AM777_Lead_Capture_CRM_StrictContact.xlsx
   - Fresh lead capture workbook.
   - Main tabs: Dashboard, Lead_Inbox, Follow_Up_Pipeline, Chatbot_Capture_Log, Automation_Log, Settings, AppsScript_Setup.
   - Contact_Number_REQUIRED is mandatory.

3. AM777_Lead_Webhook_StrictContact.gs
   - Paste into Extensions > Apps Script.
   - Deletes nothing.
   - Creates/refreshes required tabs when setupAM777LeadCRM() runs.
   - Rejects leads if Full_Name or Contact_Number is missing.
   - Routes valid leads into Lead_Inbox, Follow_Up_Pipeline, Chatbot_Capture_Log, and Automation_Log.

Setup:
1. Upload/open AM777_Lead_Capture_CRM_StrictContact.xlsx in Google Sheets.
2. Go to Extensions > Apps Script.
3. Delete the default myFunction() code.
4. Paste AM777_Lead_Webhook_StrictContact.gs.
5. Save.
6. Run setupAM777LeadCRM() once and authorize.
7. Deploy > New Deployment > Web app.
8. Execute as: Me.
9. Who has access: Anyone.
10. Copy the Web App URL.
11. Open index.html and replace:
   const APPS_SCRIPT_URL = 'PASTE_YOUR_DEPLOYED_APPS_SCRIPT_WEB_APP_URL_HERE';
12. Upload index.html to GitHub Pages.
13. Test the chatbot/form. A valid lead must include a contact number.

Recommended live test:
- Submit a chatbot inquiry with name + contact number.
- Check Lead_Inbox.
- Check Follow_Up_Pipeline.
- Check Chatbot_Capture_Log.
- Check Automation_Log.

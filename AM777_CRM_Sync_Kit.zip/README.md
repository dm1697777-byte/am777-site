
# AM777 CRM Sync Kit

This kit connects your GitHub Pages landing page to a private Google Sheets CRM.

Live landing page:
https://dm1697777-byte.github.io/am777atmtsol/

## Files

- `apps_script_backend.gs` — paste into Google Apps Script attached to your private Google Sheet.
- `github_landing_patch.js` — paste before `</body>` in your landing page or merge into your existing script.
- `README.md` — setup guide.

## Setup

### 1. Create Google Sheet

Create a new Google Sheet named:

`AM777 Lead Capture CRM`

### 2. Open Apps Script

Google Sheet → Extensions → Apps Script

Paste `apps_script_backend.gs`.

Change:

`const NOTIFY_EMAIL = "YOUR_EMAIL_HERE";`

to your email.

### 3. Run setup

Run:

`setupAM777CRM()`

Allow permissions.

This creates:

- Dashboard
- Leads
- Visitor_Events
- Follow_Up
- Services
- Setup_Guide

### 4. Deploy Web App

Apps Script → Deploy → New deployment → Web app

Settings:

- Execute as: Me
- Who has access: Anyone

Copy the Web App URL.

### 5. Connect GitHub landing page

Open your GitHub `index.html`.

Paste `github_landing_patch.js` before `</body>`.

Replace:

`PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE`

with your Web App URL.

Commit changes.

### 6. Test

Open your landing page.

Submit your form.

Check:

- Leads tab
- Dashboard tab
- localStorage backup
- email alert for Warm/Hot leads

## Privacy

Keep your Google Sheet private.
Your public landing page only sends lead/event data.
Do not put API keys or private credentials in the landing page.


/**
 * AM777 Automation Solutions — Google Sheets CRM Backend
 * Paste this into Google Apps Script attached to a private Google Sheet.
 *
 * Setup:
 * 1) Open Google Sheets → Extensions → Apps Script
 * 2) Paste this code
 * 3) Change NOTIFY_EMAIL
 * 4) Run setupAM777CRM() once
 * 5) Deploy → New deployment → Web app
 *    - Execute as: Me
 *    - Who has access: Anyone
 * 6) Copy the Web App URL into your landing page AM777_CONFIG.appsScriptEndpoint
 */

const NOTIFY_EMAIL = "YOUR_EMAIL_HERE";

const SHEETS = {
  LEADS: "Leads",
  EVENTS: "Visitor_Events",
  DASHBOARD: "Dashboard",
  FOLLOW_UP: "Follow_Up",
  SERVICES: "Services",
  SETUP: "Setup_Guide"
};

function doGet(e) {
  return text_("AM777 CRM Backend Active");
}

function doPost(e) {
  try {
    const raw = e && e.postData && e.postData.contents ? e.postData.contents : "{}";
    const payload = JSON.parse(raw);

    setupAM777CRM();

    if (payload.type === "lead") {
      const saved = appendLead_(payload);
      return json_({ success: true, message: "Lead saved", id: saved.id });
    }

    if (payload.type === "event") {
      const saved = appendEvent_(payload);
      return json_({ success: true, message: "Event saved", id: saved.id });
    }

    return json_({ success: false, message: "Unknown payload type" });
  } catch (err) {
    console.error(err);
    return json_({ success: false, message: String(err) });
  }
}

function setupAM777CRM() {
  const ss = SpreadsheetApp.getActive();

  const leads = getOrCreate_(SHEETS.LEADS);
  const events = getOrCreate_(SHEETS.EVENTS);
  const dashboard = getOrCreate_(SHEETS.DASHBOARD);
  const followUp = getOrCreate_(SHEETS.FOLLOW_UP);
  const services = getOrCreate_(SHEETS.SERVICES);
  const setup = getOrCreate_(SHEETS.SETUP);

  setupHeaders_(leads, [
    "Date", "Lead ID", "Name", "Business / Page", "Contact", "Service Needed",
    "Main Problem", "Source", "Status", "Lead Temperature", "Notes",
    "Next Follow-up", "Assigned To", "Last Updated"
  ]);

  setupHeaders_(events, [
    "Date", "Event ID", "Session ID", "Event Type", "Page", "Device",
    "Referrer", "User Agent", "Details"
  ]);

  setupHeaders_(followUp, [
    "Follow-up Date", "Lead ID", "Name", "Business / Page", "Contact",
    "Service Needed", "Status", "Priority", "Next Action", "Notes"
  ]);

  setupHeaders_(services, [
    "Service", "Best For", "What It Does", "Example Use Case", "Starting Notes"
  ]);

  if (services.getLastRow() < 2) {
    services.getRange(2,1,10,5).setValues([
      ["Landing Page + Chatbot + CRM", "Small businesses", "Captures inquiries and organizes leads", "Service page with chatbot and backend sheet", "Best main offer"],
      ["Google Sheet CRM", "Teams using spreadsheets", "Turns inquiries into trackable records", "Lead tracker and follow-up sheet", "Low-cost backend"],
      ["AI Receptionist", "Appointment businesses", "Answers common questions and routes leads", "Clinic/salon/local service inquiry helper", "Good upsell"],
      ["Bookkeeping / Accounting Workflow", "Accounting/bookkeeping", "Tracks clients, invoices, and follow-ups", "Invoice inquiry tracker", "Gary-style opportunity"],
      ["Real Estate Lead Funnel", "Agents/developers", "Qualifies buyers/sellers/renters", "Property inquiry capture", "Strong sample niche"],
      ["School Enrollment Funnel", "Schools/tutorial centers", "Captures student/parent inquiries", "Enrollment inquiry tracker", "Local PH opportunity"],
      ["Construction / Data Tracking", "Construction/project teams", "Tracks job inquiries and project updates", "Project lead tracker", "Ops-focused"],
      ["Data Analytics / Reporting", "Businesses with messy reports", "Organizes data into dashboard views", "Sales/service report dashboard", "Premium backend"],
      ["Custom Business Automation", "Any business", "Builds workflow around their process", "Custom lead/admin system", "Scope first"],
      ["Not Sure Yet", "Unsure clients", "Starts with workflow diagnosis", "Free automation fit check", "Good CTA"]
    ]);
  }

  buildDashboard_(dashboard);
  applyFormatting_(leads, events, followUp, services, setup);
  setupGuide_(setup);
}

function appendLead_(p) {
  const sh = getOrCreate_(SHEETS.LEADS);
  const now = new Date();
  const id = p.id || ("AM777-" + Date.now());
  const status = p.status || "New";
  const temp = getLeadTemperature_(p);

  const row = [
    p.submittedAt ? new Date(p.submittedAt) : now,
    id,
    safe_(p.name),
    safe_(p.business),
    safe_(p.contact),
    safe_(p.service),
    safe_(p.message || p.problem),
    safe_(p.source),
    status,
    temp,
    safe_(p.notes),
    "",
    "AM777",
    now
  ];

  sh.appendRow(row);
  styleLastRow_(sh);

  if (temp === "Warm" || temp === "Hot") {
    notifyLead_(Object.assign({}, p, { id, leadTemperature: temp, status }));
  }

  return { id };
}

function appendEvent_(p) {
  const sh = getOrCreate_(SHEETS.EVENTS);
  const now = new Date();
  const id = p.id || ("EVT-" + Date.now());

  sh.appendRow([
    p.timestamp ? new Date(p.timestamp) : now,
    id,
    safe_(p.sessionId),
    safe_(p.eventType),
    safe_(p.page),
    safe_(p.device),
    safe_(p.referrer),
    safe_(p.userAgent),
    typeof p.details === "string" ? p.details : JSON.stringify(p.details || {})
  ]);

  styleLastRow_(sh);
  return { id };
}

function getLeadTemperature_(p) {
  const text = String((p.message || p.problem || "") + " " + (p.service || "")).toLowerCase();
  const hasContact = String(p.contact || "").trim().length > 0;
  const hasService = String(p.service || "").trim().length > 0;
  const hotWords = ["asap", "today", "urgent", "need now", "quote", "pricing", "call", "demo", "interested"];
  if (hotWords.some(w => text.includes(w))) return "Hot";
  if (hasContact && hasService) return "Warm";
  return p.leadTemperature || "New";
}

function notifyLead_(p) {
  if (!NOTIFY_EMAIL || NOTIFY_EMAIL === "YOUR_EMAIL_HERE") return;

  const subject = "AM777 Warm Lead Alert";
  const body =
    "New AM777 lead received:\n\n" +
    "Lead ID: " + (p.id || "") + "\n" +
    "Name: " + (p.name || "") + "\n" +
    "Business: " + (p.business || "") + "\n" +
    "Contact: " + (p.contact || "") + "\n" +
    "Service: " + (p.service || "") + "\n" +
    "Message: " + (p.message || p.problem || "") + "\n" +
    "Source: " + (p.source || "") + "\n" +
    "Temperature: " + (p.leadTemperature || "") + "\n" +
    "Submitted: " + (p.submittedAt || new Date().toISOString());

  MailApp.sendEmail(NOTIFY_EMAIL, subject, body);
}

function buildDashboard_(sh) {
  sh.clear();

  sh.getRange("A1:L1").merge().setValue("AM777 AUTOMATION SOLUTIONS — Lead Capture & Automation CRM");
  sh.getRange("A2:L2").merge().setValue("Landing Page → Chatbot/Form → CRM Sheet → Follow-up Dashboard");

  const metrics = [
    ["Total Leads", '=COUNTA(Leads!B2:B)'],
    ["New Leads", '=COUNTIF(Leads!I:I,"New")'],
    ["Warm Leads", '=COUNTIF(Leads!J:J,"Warm")'],
    ["Hot Leads", '=COUNTIF(Leads!J:J,"Hot")'],
    ["Follow-up", '=COUNTIF(Leads!I:I,"Follow-up")'],
    ["Booked Calls", '=COUNTIF(Leads!I:I,"Booked")'],
    ["Closed Leads", '=COUNTIF(Leads!I:I,"Closed")'],
    ["Total Visits", '=COUNTIF(Visitor_Events!D:D,"page_visit")'],
    ["CTA Clicks", '=COUNTIF(Visitor_Events!D:D,"cta_click")'],
    ["Chatbot Opens", '=COUNTIF(Visitor_Events!D:D,"chatbot_open")'],
    ["Form Submits", '=COUNTIF(Visitor_Events!D:D,"form_submit")'],
    ["Conversion Rate", '=IFERROR(COUNTA(Leads!B2:B)/COUNTIF(Visitor_Events!D:D,"page_visit"),0)']
  ];

  let r = 4;
  for (let i = 0; i < metrics.length; i++) {
    const col = (i % 4) * 3 + 1;
    const row = r + Math.floor(i / 4) * 3;
    sh.getRange(row, col, 2, 2).merge();
    sh.getRange(row, col).setValue(metrics[i][0]);
    sh.getRange(row + 2, col, 1, 2).merge();
    sh.getRange(row + 2, col).setFormula(metrics[i][1]);
  }

  sh.getRange("A15:L15").merge().setValue("Recent Leads");
  sh.getRange("A16:H16").setValues([["Date", "Lead ID", "Name", "Business", "Contact", "Service", "Status", "Temp"]]);
  sh.getRange("A17:H26").setFormula('=IFERROR(QUERY(Leads!A2:J,"select A,B,C,D,E,F,I,J where B is not null order by A desc limit 10",0),"")');

  sh.getRange("A29:F29").merge().setValue("Latest Visitor Events");
  sh.getRange("A30:F30").setValues([["Date", "Event ID", "Session", "Event Type", "Page", "Device"]]);
  sh.getRange("A31:F40").setFormula('=IFERROR(QUERY(Visitor_Events!A2:F,"select A,B,C,D,E,F where B is not null order by A desc limit 10",0),"")');

  sh.getRange("H29:L29").merge().setValue("Lead Status Summary");
  sh.getRange("H30:I35").setValues([
    ["Status", "Count"],
    ["New", '=COUNTIF(Leads!I:I,"New")'],
    ["Follow-up", '=COUNTIF(Leads!I:I,"Follow-up")'],
    ["Booked", '=COUNTIF(Leads!I:I,"Booked")'],
    ["Closed", '=COUNTIF(Leads!I:I,"Closed")'],
    ["Hot", '=COUNTIF(Leads!J:J,"Hot")']
  ]);

  sh.setFrozenRows(2);
  sh.getRange("A1:L2").setBackground("#071126").setFontColor("#FFFFFF").setFontWeight("bold");
  sh.getRange("A1").setFontSize(18);
  sh.getRange("A2").setFontSize(11);
  sh.getRange("A4:L12").setBackground("#FFFFFF").setFontColor("#111827");
  sh.getRange("A15:L15").setBackground("#071126").setFontColor("#FFFFFF").setFontWeight("bold");
  sh.getRange("A29:L29").setBackground("#071126").setFontColor("#FFFFFF").setFontWeight("bold");
  sh.getRange("A16:H16").setBackground("#E5E7EB").setFontWeight("bold");
  sh.getRange("A30:F30").setBackground("#E5E7EB").setFontWeight("bold");
  sh.getRange("H30:I30").setBackground("#E5E7EB").setFontWeight("bold");
  sh.getDataRange().setFontFamily("Arial").setFontSize(11);
  sh.getRange("A1:L2").setHorizontalAlignment("center");
  sh.autoResizeColumns(1, 12);
}

function applyFormatting_(leads, events, followUp, services, setup) {
  [leads, events, followUp, services, setup].forEach(sh => {
    sh.setFrozenRows(1);
    sh.getDataRange().setFontFamily("Arial").setFontSize(11).setWrap(true).setVerticalAlignment("middle");
    sh.getRange(1,1,1,Math.max(1, sh.getLastColumn())).setBackground("#071126").setFontColor("#FFFFFF").setFontWeight("bold");
    if (sh.getLastRow() > 1) sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).setBackground("#FFFFFF");
    sh.autoResizeColumns(1, Math.max(1, sh.getLastColumn()));
  });

  const statusRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(["New", "Warm", "Hot", "Follow-up", "Booked", "Closed"], true)
    .setAllowInvalid(false)
    .build();
  leads.getRange("I2:I1000").setDataValidation(statusRule);

  const tempRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(["New", "Warm", "Hot"], true)
    .setAllowInvalid(false)
    .build();
  leads.getRange("J2:J1000").setDataValidation(tempRule);

  const priorityRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(["Low", "Medium", "High", "Urgent"], true)
    .setAllowInvalid(false)
    .build();
  followUp.getRange("H2:H1000").setDataValidation(priorityRule);

  addStatusFormatting_(leads.getRange("I2:J1000"));
  addStatusFormatting_(followUp.getRange("G2:H1000"));
}

function addStatusFormatting_(range) {
  const rules = [
    SpreadsheetApp.newConditionalFormatRule().whenTextContains("Hot").setBackground("#FEE2E2").setFontColor("#991B1B").setRanges([range]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextContains("Warm").setBackground("#FEF3C7").setFontColor("#92400E").setRanges([range]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextContains("Follow-up").setBackground("#EDE9FE").setFontColor("#5B21B6").setRanges([range]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextContains("Booked").setBackground("#DCFCE7").setFontColor("#166534").setRanges([range]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextContains("Closed").setBackground("#E5E7EB").setFontColor("#374151").setRanges([range]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextContains("Urgent").setBackground("#FFEDD5").setFontColor("#9A3412").setRanges([range]).build()
  ];
  const sh = range.getSheet();
  sh.setConditionalFormatRules(sh.getConditionalFormatRules().concat(rules));
}

function setupGuide_(sh) {
  if (sh.getLastRow() > 1) return;
  sh.getRange("A2:B9").setValues([
    ["Step 1", "Run setupAM777CRM() once."],
    ["Step 2", "Deploy Apps Script as a Web App: Execute as Me, Access Anyone."],
    ["Step 3", "Copy the Web App URL."],
    ["Step 4", "Paste the URL into AM777_CONFIG.appsScriptEndpoint in your GitHub landing page."],
    ["Step 5", "Test bottom form and chatbot submissions."],
    ["Step 6", "Check Leads and Visitor_Events tabs."],
    ["Step 7", "Use Dashboard tab for screenshot/demo."],
    ["Security", "Keep this Google Sheet private. Public landing page sends data only."]
  ]);
  sh.autoResizeColumns(1, 2);
}

function getOrCreate_(name) {
  const ss = SpreadsheetApp.getActive();
  return ss.getSheetByName(name) || ss.insertSheet(name);
}

function setupHeaders_(sh, headers) {
  if (sh.getLastRow() === 0 || sh.getRange(1,1).getValue() === "") {
    sh.getRange(1,1,1,headers.length).setValues([headers]);
  }
}

function styleLastRow_(sh) {
  const row = sh.getLastRow();
  const col = sh.getLastColumn();
  sh.getRange(row, 1, 1, col).setWrap(true).setVerticalAlignment("middle");
}

function safe_(v) {
  return v == null ? "" : String(v).slice(0, 5000);
}

function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function text_(txt) {
  return ContentService
    .createTextOutput(txt)
    .setMimeType(ContentService.MimeType.TEXT);
}

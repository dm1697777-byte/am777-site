AM777 Live GitHub Lead Sync — Strict Contact Setup

Files:
1. AM777_Live_GitHub_Lead_CRM_StrictContact.xlsx
2. AM777_Live_GitHub_Webhook_StrictContact.gs
3. index.html

Live Web App URL already used in index.html:
https://script.google.com/macros/s/AKfycbxuU0g9mUX5LqkeRl1TMJBaZdnESqkWsgasoBus94SdzW4XW-LNcRYjqwVRGTqseQmp/exec

Setup:
1. Upload the XLSX to Google Drive.
2. Open it with Google Sheets.
3. Go to Extensions > Apps Script.
4. Delete the default myFunction() code.
5. Paste the full code from AM777_Live_GitHub_Webhook_StrictContact.gs.
6. Save.
7. Run setupAM777LeadCRM() once and accept permissions.
8. Deploy as Web App:
   - Execute as: Me
   - Who has access: Anyone
9. If Google gives a new Web App URL, paste that URL into index.html:
   const APPS_SCRIPT_URL = 'YOUR_WEB_APP_URL';
10. Upload index.html to GitHub Pages.
11. Test the chatbot/form using a real contact number.

Strict contact rule:
- Full_Name is required.
- Contact_Number is required.
- The script rejects leads without at least 8 phone digits.

Fresh lead routing:
- Lead_Inbox
- Follow_Up_Pipeline
- Chatbot_Capture_Log
- Automation_Log

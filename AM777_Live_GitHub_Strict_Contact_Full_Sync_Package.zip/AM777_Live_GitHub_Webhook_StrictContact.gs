const SPREADSHEET_ID = '';
const CRM_SHEETS = {
  leadInbox: 'Lead_Inbox',
  pipeline: 'Follow_Up_Pipeline',
  chatbotLog: 'Chatbot_Capture_Log',
  automationLog: 'Automation_Log'
};

function doGet() {
  return json_({ status: 'ok', system: 'AM777 Live GitHub Lead Webhook', required: ['full_name', 'contact_number'] });
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const ss = getWorkbook_();
    ensureRequiredSheets_(ss);
    const data = parsePayload_(e);
    const now = new Date();
    const tz = Session.getScriptTimeZone() || 'Asia/Manila';
    const name = clean_(pick_(data, ['full_name', 'name', 'Full_Name', 'fullName']));
    const contactNumber = clean_(pick_(data, ['contact_number', 'contactNumber', 'phone', 'mobile', 'contact', 'Contact_Number']));
    const phoneDigits = digits_(contactNumber);
    const email = clean_(pick_(data, ['email', 'Email']));
    const business = clean_(pick_(data, ['business_name', 'business', 'Business_Name', 'project', 'company']));
    const service = clean_(pick_(data, ['service_interest', 'serviceInterest', 'serviceInterested', 'service', 'Service_Interest'])) || 'Not sure yet';
    const problem = clean_(pick_(data, ['main_problem', 'problem', 'message', 'Main_Problem'])) || 'Not specified';
    const timeline = clean_(pick_(data, ['timeline', 'urgency', 'Timeline'])) || 'Not specified';
    const source = clean_(pick_(data, ['source_page', 'source', 'page', 'Source_Page'])) || 'github_funnel';
    if (!name || !contactNumber || phoneDigits.length < 8) {
      appendAutomationLog_(ss, now, 'Lead Rejected', 'Failed', 'Missing required full_name or valid contact_number.', '', source);
      return json_({ status: 'error', message: 'Full name and valid contact number are required.' });
    }
    const leadId = makeLeadId_(now, tz);
    const priority = computePriority_(timeline, service);
    const status = 'New';
    const followUpDate = computeFollowUpDate_(now, priority);
    const lastAction = 'Lead captured from live GitHub funnel';
    const rawJson = JSON.stringify(data);
    const wa = makeWhatsAppLink_(contactNumber);
    const contactLink = wa || (email ? 'mailto:' + email : '');
    const leadRow = [
      now, leadId, name, contactNumber, email, business, service, problem, timeline, source,
      status, priority, followUpDate, lastAction, '', wa, contactLink, rawJson
    ];
    const leadSheet = ss.getSheetByName(CRM_SHEETS.leadInbox);
    leadSheet.getRange(Math.max(leadSheet.getLastRow() + 1, 5), 1, 1, leadRow.length).setValues([leadRow]);
    const pipeRow = [now, leadId, name, contactNumber, service, status, priority, followUpDate, lastAction, contactLink, 'AM777', ''];
    const pipeSheet = ss.getSheetByName(CRM_SHEETS.pipeline);
    pipeSheet.getRange(Math.max(pipeSheet.getLastRow() + 1, 4), 1, 1, pipeRow.length).setValues([pipeRow]);
    const chatRow = [now, leadId, source, name, contactNumber, service, 'Strict contact capture', problem, rawJson];
    const chatSheet = ss.getSheetByName(CRM_SHEETS.chatbotLog);
    chatSheet.getRange(Math.max(chatSheet.getLastRow() + 1, 4), 1, 1, chatRow.length).setValues([chatRow]);
    appendAutomationLog_(ss, now, 'Lead Captured', 'Success', name + ' | ' + contactNumber + ' | ' + service, leadId, source);
    return json_({ status: 'success', message: 'Lead saved', lead_id: leadId, priority: priority });
  } catch (err) {
    try {
      const ss = getWorkbook_();
      appendAutomationLog_(ss, new Date(), 'Webhook Error', 'Failed', String(err), '', 'doPost');
    } catch (innerErr) {}
    return json_({ status: 'error', message: String(err) });
  } finally {
    lock.releaseLock();
  }
}

function setupAM777LeadCRM() {
  const ss = getWorkbook_();
  const leadHeaders = ['Timestamp','Lead_ID','Full_Name','Contact_Number','Email','Business_Name','Service_Interest','Main_Problem','Timeline','Source_Page','Status','Priority','Follow_Up_Date','Last_Action','Notes','WhatsApp_Link','Contact_Link','Raw_JSON'];
  const pipelineHeaders = ['Timestamp','Lead_ID','Full_Name','Contact_Number','Service_Interest','Status','Priority','Follow_Up_Date','Last_Action','Contact_Link','Owner','Notes'];
  const chatHeaders = ['Timestamp','Lead_ID','Capture_Source','Full_Name','Contact_Number','Service_Interest','Bot_Path','Raw_Message','Raw_JSON'];
  const logHeaders = ['Timestamp','Event','Status','Message','Lead_ID','Source'];
  refreshSheet_(ss, CRM_SHEETS.leadInbox, 'Lead Inbox — Fresh Live Leads from GitHub Funnel / Chatbot', 'Required fields: Full_Name + Contact_Number. Leads without a usable contact number are rejected.', leadHeaders, 4);
  refreshSheet_(ss, CRM_SHEETS.pipeline, 'Follow-Up Pipeline — Action Board', '', pipelineHeaders, 3);
  refreshSheet_(ss, CRM_SHEETS.chatbotLog, 'Chatbot Capture Log — raw audit trail', '', chatHeaders, 3);
  refreshSheet_(ss, CRM_SHEETS.automationLog, 'Automation Log — delivery, validation, and errors', '', logHeaders, 3);
  const leadSheet = ss.getSheetByName(CRM_SHEETS.leadInbox);
  setValidation_(leadSheet.getRange('K5:K1000'), ['New','Contacted','Qualified','Proposal Sent','Won','Lost','Archived']);
  setValidation_(leadSheet.getRange('L5:L1000'), ['Hot','Warm','Medium','Cold','Needs Discovery']);
  setValidation_(leadSheet.getRange('G5:G1000'), ['Lead Capture Automation','Instant Response System','CRM / Google Sheets Tracker','AI Chatbot','Website / Landing Page','Document Extraction','Not sure yet']);
  setValidation_(leadSheet.getRange('I5:I1000'), ['ASAP','This week','This month','Just exploring','Not specified']);
  const pipeSheet = ss.getSheetByName(CRM_SHEETS.pipeline);
  setValidation_(pipeSheet.getRange('F4:F1000'), ['New','Contacted','Qualified','Proposal Sent','Won','Lost','Archived']);
  setValidation_(pipeSheet.getRange('G4:G1000'), ['Hot','Warm','Medium','Cold','Needs Discovery']);
  appendAutomationLog_(ss, new Date(), 'CRM Setup', 'Success', 'Tabs refreshed and strict contact capture is ready.', '', 'setupAM777LeadCRM');
}

function getWorkbook_() {
  return SPREADSHEET_ID ? SpreadsheetApp.openById(SPREADSHEET_ID) : SpreadsheetApp.getActiveSpreadsheet();
}

function ensureRequiredSheets_(ss) {
  Object.keys(CRM_SHEETS).forEach(function(k) {
    if (!ss.getSheetByName(CRM_SHEETS[k])) ss.insertSheet(CRM_SHEETS[k]);
  });
}

function refreshSheet_(ss, name, title, subtitle, headers, headerRow) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  sh.clear();
  sh.getRange(1, 1, 1, headers.length).merge().setValue(title).setFontWeight('bold').setFontSize(15).setBackground('#EAF7EF').setHorizontalAlignment('center');
  if (subtitle) sh.getRange(2, 1, 1, headers.length).merge().setValue(subtitle).setFontColor('#6B7280').setWrap(true);
  sh.getRange(headerRow, 1, 1, headers.length).setValues([headers]).setFontWeight('bold').setBackground('#DFF3E7').setHorizontalAlignment('center').setWrap(true);
  sh.setFrozenRows(headerRow);
  sh.autoResizeColumns(1, headers.length);
}

function setValidation_(range, values) {
  const rule = SpreadsheetApp.newDataValidation().requireValueInList(values, true).setAllowInvalid(false).build();
  range.setDataValidation(rule);
}

function appendAutomationLog_(ss, timestamp, event, status, message, leadId, source) {
  let sh = ss.getSheetByName(CRM_SHEETS.automationLog);
  if (!sh) sh = ss.insertSheet(CRM_SHEETS.automationLog);
  if (sh.getLastRow() < 3) sh.getRange(3, 1, 1, 6).setValues([['Timestamp','Event','Status','Message','Lead_ID','Source']]);
  sh.getRange(Math.max(sh.getLastRow() + 1, 4), 1, 1, 6).setValues([[timestamp, event, status, message, leadId, source]]);
}

function parsePayload_(e) {
  const data = {};
  if (e && e.parameter) Object.assign(data, e.parameter);
  const contents = e && e.postData && e.postData.contents ? e.postData.contents : '';
  if (!contents) return data;
  try {
    const parsed = JSON.parse(contents);
    Object.assign(data, parsed);
    return data;
  } catch (err) {}
  contents.split('&').forEach(function(pair) {
    const parts = pair.split('=');
    if (!parts[0]) return;
    const key = decodeURIComponent(parts[0].replace(/\+/g, ' '));
    const value = decodeURIComponent((parts.slice(1).join('=') || '').replace(/\+/g, ' '));
    data[key] = value;
  });
  return data;
}

function pick_(obj, keys) {
  for (let i = 0; i < keys.length; i++) {
    if (obj[keys[i]] !== undefined && obj[keys[i]] !== null && String(obj[keys[i]]).trim() !== '') return obj[keys[i]];
  }
  return '';
}

function clean_(value) {
  return String(value || '').trim();
}

function digits_(value) {
  return String(value || '').replace(/\D/g, '');
}

function makeLeadId_(date, tz) {
  return 'AM777-' + Utilities.formatDate(date, tz, 'yyyyMMdd-HHmmss') + '-' + Math.floor(1000 + Math.random() * 9000);
}

function computePriority_(timeline, service) {
  const t = String(timeline || '').toLowerCase();
  if (t.indexOf('asap') > -1 || t.indexOf('this week') > -1) return 'Hot';
  if (t.indexOf('this month') > -1) return 'Warm';
  if (String(service || '').toLowerCase().indexOf('not sure') > -1) return 'Needs Discovery';
  return 'Medium';
}

function computeFollowUpDate_(now, priority) {
  const d = new Date(now);
  if (priority === 'Hot') return d;
  d.setDate(d.getDate() + 1);
  return d;
}

function makeWhatsAppLink_(phone) {
  let d = digits_(phone);
  if (!d || d.length < 8) return '';
  if (d.charAt(0) === '0') d = '63' + d.substring(1);
  return 'https://wa.me/' + d;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
